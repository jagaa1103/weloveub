import { Injectable, Inject } from '@angular/core';
// import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import * as firebase from 'firebase';
import {AngularFire, FirebaseDatabase, FirebaseRef, FirebaseListObservable, FirebaseObjectObservable} from 'angularfire2';


declare var firebase: any;

@Injectable()
export class DataService {
  datas = [];
  items: FirebaseListObservable<any[]>;
  ref: any;
  db: FirebaseDatabase
  greeting: FirebaseObjectObservable<any>;
  constructor(af: AngularFire) {
    this.ref = firebase.storage().ref;
    this.db = af.database;
    this.greeting = af.database.object('/greeting');
    this.greeting.subscribe(snapshot => console.log(snapshot));

    var connectedRef = firebase.database().ref(".info/connected");
    connectedRef.on("value", function(snap) {
      if (snap.val() === true) {
        console.log("connected");
      } else {
        console.log("not connected");
      }
    });
  }

  getAllData(){
    return this.db.list('items');
  }

  saveItem(item: Info){
    // this.saveObject(item);
    return new Promise(resolve => {
        this.db.list('/items').push(item);
        resolve(true);
    });
  }

  saveObject(item: Info){
    
    window.history.back();
  }
  uploadPhotos(){
  }

}

export class Info {
  type: String;
  title: String;
  phone: number;
  time: String;
  location: Location;
  photos: any[];
  others: String;
}
export class Location{
  latitude: String;
  longitude: String;
}

export class Photo{
  image: String;
}

